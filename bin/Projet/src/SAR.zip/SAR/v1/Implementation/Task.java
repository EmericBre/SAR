package SAR.v1.Implementation;

public abstract class Task extends Thread {

	
}
