package SAR.v3.Implementation;

public abstract class Task extends Thread {

	
}
