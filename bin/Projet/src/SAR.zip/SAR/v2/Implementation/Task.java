package SAR.v2.Implementation;

public abstract class Task extends Thread {

	
}
