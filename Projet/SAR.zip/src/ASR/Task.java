package ASR;

public abstract class Task extends Thread {

	
}
